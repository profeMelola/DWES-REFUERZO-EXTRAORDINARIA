package es.daw.extra_peliculas_mvc.exception;

public class FavoriteAlreadyExistsExcepcion extends RuntimeException{
    public FavoriteAlreadyExistsExcepcion(String message){
        super(message);
    }
}
