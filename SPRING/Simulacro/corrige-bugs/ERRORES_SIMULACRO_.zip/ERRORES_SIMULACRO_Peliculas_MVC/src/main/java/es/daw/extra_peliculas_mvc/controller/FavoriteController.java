package es.daw.extra_peliculas_mvc.controller;

import es.daw.extra_peliculas_mvc.dto.MovieResponseDto;
import es.daw.extra_peliculas_mvc.entity.AppUser;
import es.daw.extra_peliculas_mvc.entity.Favorite;
import es.daw.extra_peliculas_mvc.exception.FavoriteAlreadyExistsExcepcion;
import es.daw.extra_peliculas_mvc.service.FavoriteService;
import es.daw.extra_peliculas_mvc.service.MovieService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/favorites")
@RequiredArgsConstructor
public class FavoriteController {

    private final FavoriteService favoriteService;
    private final MovieService movieService;

    @GetMapping
    public String list(@AuthenticationPrincipal AppUser user, Model model) {

        List<Favorite> favorites = favoriteService.getFavorites(user);

        List<MovieResponseDto> movies = favorites.stream()
                .map( f -> movieService.getMovieById(f.getMovieId()))
                .filter(Optional::isPresent)
                .map(Optional::get)
                .toList();

        // ---------- imperativo ------------
//        List<MovieResponseDto> movies = new ArrayList<>();
//        for  (Favorite favorite : favorites) {
//            Optional<MovieResponseDto> opt = movieService.getMovieById(favorite.getMovieId());
//            if (opt.isPresent()) {
//                movies.add(opt.get());
//            }
//        }

        model.addAttribute("movies", movies);
        return "favorites"; // nombre de la vista (página html thymeleaf)

    }

    @PostMapping("/add/{movieId}")
    public String add(@AuthenticationPrincipal AppUser user,
                      @PathVariable Long movieId,
                      RedirectAttributes redirectAttributes) {

        try {
            favoriteService.addFavorite(user, movieId);
        }catch (FavoriteAlreadyExistsExcepcion ex){
            redirectAttributes.addFlashAttribute("message", ex.getMessage());
        }

        return "redirect:/movies";
    }

    @PostMapping("/{id}/delete")
    public String delete(@AuthenticationPrincipal AppUser user,
                         @PathVariable Long id,
                         RedirectAttributes redirectAttributes) {

        favoriteService.removeFavorite(user, id);
        redirectAttributes.addFlashAttribute("mensaje","Película eliminada de favoritos");

        return "redirect:/favorites"; //endpoint. No es el nombre de una plantilla (vista)
    }
}
