package es.daw.extra_peliculas_mvc.repository;

import es.daw.extra_peliculas_mvc.entity.AppUser;
import es.daw.extra_peliculas_mvc.entity.Favorite;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface FavoriteRepository extends JpaRepository<Favorite, Integer> {

    boolean existsByUserAndMovieId(AppUser appUser, Long movieId);

    List<Favorite> findByUser(AppUser appUser);

    Optional<Favorite> findByUserAndMovieId(AppUser appUser, Long movieId);

}
