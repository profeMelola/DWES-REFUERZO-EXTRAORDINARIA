package es.daw.extra_peliculas_mvc.service;

import es.daw.extra_peliculas_mvc.entity.AppUser;
import es.daw.extra_peliculas_mvc.entity.Favorite;
import es.daw.extra_peliculas_mvc.exception.FavoriteAlreadyExistsExcepcion;
import es.daw.extra_peliculas_mvc.repository.FavoriteRepository;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class FavoriteService {

    private final FavoriteRepository favoriteRepository;

    @Transactional
    public void addFavorite(AppUser appUser, Long movieId){

        if (favoriteRepository.existsByUserAndMovieId(appUser, movieId)){
            //throw new RuntimeException("Esta película ya está en tus favoritos");
            throw new FavoriteAlreadyExistsExcepcion("Esta película ya está en tus favoritos");
        }

        Favorite favorite = new Favorite();
        favorite.setUser(appUser);
        favorite.setMovieId(movieId);
        favorite.setCreatedAt(LocalDate.now());
        favoriteRepository.save(favorite);

    }

    @Transactional(readOnly = true)
    public List<Favorite> getFavorites(AppUser appUser){
        //return favoriteRepository.findAll(); // devuelve todos, de todos los usuarios!!!! noooooooooooooo

        return favoriteRepository.findByUser(appUser);


    }

    @Transactional
    public void removeFavorite(AppUser appUser, Long movieId){
        favoriteRepository.findByUserAndMovieId(appUser, movieId).ifPresent(favorite -> {
            favoriteRepository.delete(favorite);
        });
    }

}
