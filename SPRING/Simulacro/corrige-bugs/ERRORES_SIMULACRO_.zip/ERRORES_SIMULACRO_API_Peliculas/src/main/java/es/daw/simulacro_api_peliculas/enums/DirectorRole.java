package es.daw.simulacro_api_peliculas.enums;

// PENDIENTE!!! ENUMERADO COMPLEJO!!!!
public enum DirectorRole {
    DIRECTOR,
    CO_DIRECTOR,
    ASSISTANT
}
