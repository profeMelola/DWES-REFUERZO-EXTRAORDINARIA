package es.daw.simulacro_api_peliculas.repository;

import es.daw.simulacro_api_peliculas.entity.Review;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReviewRepository extends JpaRepository<Review, Integer> {
}
