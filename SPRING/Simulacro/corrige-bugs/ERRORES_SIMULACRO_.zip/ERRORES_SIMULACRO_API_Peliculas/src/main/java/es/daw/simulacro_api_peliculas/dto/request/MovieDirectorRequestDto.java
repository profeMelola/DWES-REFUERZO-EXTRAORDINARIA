package es.daw.simulacro_api_peliculas.dto.request;

import es.daw.simulacro_api_peliculas.enums.DirectorRole;
import jakarta.validation.constraints.NotNull;

public record MovieDirectorRequestDto(
        @NotNull(message = "El id del director es obligatorio")
        Long directorId,

        @NotNull(message = "El rol es obligatorio")
        DirectorRole role,

        boolean credited
) {}