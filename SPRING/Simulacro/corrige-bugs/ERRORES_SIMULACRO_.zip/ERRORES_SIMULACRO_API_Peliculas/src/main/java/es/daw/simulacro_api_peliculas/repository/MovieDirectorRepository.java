package es.daw.simulacro_api_peliculas.repository;

import es.daw.simulacro_api_peliculas.entity.MovieDirector;
import es.daw.simulacro_api_peliculas.entity.MovieDirectorId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovieDirectorRepository extends JpaRepository<MovieDirector, MovieDirectorId> {}
