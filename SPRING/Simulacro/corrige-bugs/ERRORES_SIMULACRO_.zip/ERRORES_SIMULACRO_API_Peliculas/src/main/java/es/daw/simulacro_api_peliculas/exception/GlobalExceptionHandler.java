package es.daw.simulacro_api_peliculas.exception;

import es.daw.simulacro_api_peliculas.dto.error.ActorConflictResponseDto;
import es.daw.simulacro_api_peliculas.dto.error.ErrorResponseDto;
import es.daw.simulacro_api_peliculas.enums.Genre;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

    // Inyectamos HttpServletRequest solo para poder llamar a request.getRequestURI() y meter la ruta en el ErrorResponseDto
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponseDto> handleNotFound(
            ResourceNotFoundException ex,
            HttpServletRequest request) {

        return buildResponse(HttpStatus.NOT_FOUND, ex.getMessage(), request);
    }

    @ExceptionHandler(ConflictException.class)
    public ResponseEntity<ErrorResponseDto> handleConflict(
            ConflictException ex,
            HttpServletRequest request) {

        return buildResponse(HttpStatus.CONFLICT, ex.getMessage(), request);
    }

    @ExceptionHandler(ActorConflictException.class)
    public ResponseEntity<ActorConflictResponseDto> handleConflictActor(
            ActorConflictException ex,
            HttpServletRequest request) {

        ActorConflictResponseDto body = new ActorConflictResponseDto(
          LocalDateTime.now(),
          HttpStatus.CONFLICT.value(),
                HttpStatus.CONFLICT.getReasonPhrase(),
                ex.getMessage(),
                request.getRequestURI(),
                ex.getParticipaciones()
        );
        return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponseDto> handleValidation(
            MethodArgumentNotValidException ex,
            HttpServletRequest request
    ){
        String message = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map( fe -> fe.getField()+" : "+ fe.getDefaultMessage())
                .collect(Collectors.joining(", "));

        return buildResponse(HttpStatus.BAD_REQUEST, message, request);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponseDto> handleEnumMismatch(
            MethodArgumentTypeMismatchException ex,
            HttpServletRequest request) {

        String valoresValidos = Arrays.stream(Genre.values())
                .map(Enum::name)
                .collect(Collectors.joining(", "));

        String message = "Valor inválido '%s' para el parámetro '%s'. Valores permitidos: %s"
                .formatted(ex.getValue(), ex.getName(), valoresValidos);

        return buildResponse(HttpStatus.BAD_REQUEST, message, request);
    }


    @ExceptionHandler(BusinessRuleException.class)
    public ResponseEntity<ErrorResponseDto> handleBusinessRule(
            BusinessRuleException ex,
            HttpServletRequest request) {
        return buildResponse(HttpStatus.UNPROCESSABLE_ENTITY, ex.getMessage(), request);
    }

    /**
     * Construye un objeto ResponseEntity que encapsula un ErrorResponseDto
     * @param status
     * @param message
     * @param request
     * @return
     */
    private ResponseEntity<ErrorResponseDto> buildResponse(HttpStatus status,
                                                           String message,
                                                           HttpServletRequest request) {

        ErrorResponseDto body = new ErrorResponseDto(
                LocalDateTime.now(),
                status.value(),
                status.getReasonPhrase(),
                message,
                request.getRequestURI()
        );

        return ResponseEntity.status(status).body(body);

    }

}
