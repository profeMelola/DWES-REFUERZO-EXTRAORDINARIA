package es.daw.simulacro_api_peliculas.mapper;

import es.daw.simulacro_api_peliculas.dto.review.ReviewResponseDto;
import es.daw.simulacro_api_peliculas.entity.Review;
import org.springframework.stereotype.Component;

@Component
public class ReviewMapper {

    public ReviewResponseDto toResponseDto(Review review) {
        return new ReviewResponseDto(
                review.getId(),
                review.getAuthor(),
                review.getBody(),
                review.getRating(),
                review.getCreatedAt(),
                review.getMovie().getId(),
                review.getMovie().getTitle()
        );
    }
}
