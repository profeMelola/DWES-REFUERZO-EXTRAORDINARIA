package es.daw.simulacro_api_peliculas.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name="reviews")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Review {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80)
    private String author;

    @Column(nullable = false, length = 500)
    private String body;

    @Column(nullable = false)
    private int rating;

    @Column(name="created_at",nullable = false)
    private LocalDate createdAt;

    @Column(nullable = false)
    private boolean active;

    /* ESTRATEGIAS POR DEFECO
    @OneToMany → LAZY por defecto en JPA
    @ManyToMany → LAZY por defecto
    @ManyToOne → EAGER por defecto ⚠️
    @OneToOne → EAGER por defecto ⚠️

    El caso de AppUser → Role con EAGER está justificado porque
    Spring Security necesita los roles disponibles inmediatamente al cargar el usuario en cada petición
    — si fuera LAZY fallaría!!

     */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "movie_id", nullable = false)
    private Movie movie;

}
