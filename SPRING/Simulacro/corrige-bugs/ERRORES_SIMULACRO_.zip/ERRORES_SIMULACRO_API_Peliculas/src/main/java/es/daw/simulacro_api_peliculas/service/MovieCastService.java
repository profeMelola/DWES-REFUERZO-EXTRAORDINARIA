package es.daw.simulacro_api_peliculas.service;

import es.daw.simulacro_api_peliculas.dto.error.ActorParticipacionDto;
import es.daw.simulacro_api_peliculas.dto.request.MovieCastRequestDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieCastResponseDto;
import es.daw.simulacro_api_peliculas.entity.Actor;
import es.daw.simulacro_api_peliculas.entity.Movie;
import es.daw.simulacro_api_peliculas.entity.MovieCast;
import es.daw.simulacro_api_peliculas.entity.MovieCastId;
import es.daw.simulacro_api_peliculas.exception.ActorConflictException;
import es.daw.simulacro_api_peliculas.exception.ConflictException;
import es.daw.simulacro_api_peliculas.exception.ResourceNotFoundException;
import es.daw.simulacro_api_peliculas.mapper.ActorMapper;
import es.daw.simulacro_api_peliculas.repository.ActorRepository;
import es.daw.simulacro_api_peliculas.repository.MovieCastRepository;
import es.daw.simulacro_api_peliculas.repository.MovieRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class MovieCastService {

    private final MovieRepository movieRepository;
    private final ActorRepository actorRepository;
    private final MovieCastRepository movieCastRepository;
    private final ActorMapper actorMapper;

    @Transactional
    public void addActorToMovie(Long movieId, MovieCastRequestDto dto) {

        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Película no encontrado con id: "+movieId
                ));

        Actor actor = actorRepository.findById(dto.actorId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Actor no encontrado con id: " + dto.actorId()
                ));

        // ---- código que detecta si el actor participa ya en la peli ---
        MovieCastId castId = new MovieCastId(movieId, dto.actorId());

        // La gestión de si existe se hace con la colección de java
        boolean alreadyExists = movie.getMovieCast().stream()
                .anyMatch(mc -> mc.getId().equals(castId));

        if(alreadyExists){
            throw new ConflictException(
                    "El actor ya tiene un rol en esta película"
            );
        }
        // ---------------------------

        MovieCast movieCast = new MovieCast();
        movieCast.setId(castId);
        movieCast.setMovie(movie);
        movieCast.setActor(actor);
        movieCast.setCharacterName(dto.characterName());
        movieCast.setScreenMinutes(dto.screenMinutes());
        movieCast.setSalaryOverride(dto.salaryOverride());

        movie.addMovieCast(movieCast);

        // No es necesario!!!
        //movieRepository.save(movie);

        //movieCastRepository.save(movieCast); // se salvaría en BD, en la tabla MovieCast pero Movie no estaría actualizado (el Set)

        System.out.println("****************************");
        System.out.println("** LISTADO DE PERSONAJES: " + movie.getMovieCast());
        System.out.println("****************************");

    }

    @Transactional(readOnly = true)
    public MovieCastResponseDto getMovieCast(Long movieId, Long actorId) {

        MovieCastId id = new MovieCastId(movieId, actorId);

        MovieCast movieCast = movieCastRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "MovieCast no encontrado para movieId: " + movieId + " actorId: " + actorId));

        Movie movie = movieCast.getMovie();
        Actor actor = movieCast.getActor();

        return new MovieCastResponseDto(
                movie.getId(),
                movie.getTitle(),
                movie.getReleaseYear(),
                movie.getGenre(),
                movie.isActive(),
                actor.getId(),
                actor.getStageName()
        );
    }

    @Transactional
    public void deleteMovie(Long movieId) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new ResourceNotFoundException("Película no encontrada con id: " + movieId));
        movieRepository.delete(movie);
    }



    @Transactional
    public void deleteActor(Long actorId) {

        Actor actor = actorRepository.findById(actorId)
                .orElseThrow(() -> new ResourceNotFoundException("Actor no encontrado con id: " + actorId));

        boolean hashCast = actor.getMovieCast() != null && !actor.getMovieCast().isEmpty();

        // OPCIÓN A
        if (hashCast) {

            List<ActorParticipacionDto> participaciones = actor.getMovieCast().stream()
                    .map(actorMapper::toParticipacionDto)
                    //.map( mc -> actorMapper.toParticipacionDto(mc))
                    .toList();

            //throw new ConflictException("El actor con id "+actorId+" participa en películas y no se puede borrar");
            throw new ActorConflictException("El actor participa en películas y no puede ser eliminado",participaciones);
        }
        // OPCIÓN B
        // Si solo quisieras comprobar la existencia sin necesitar los datos, por ejemplo si el mensaje de error fuera genérico sin lista de participacione
        //movieCastRepository.existsByActorId(actorId);
        //Una query directa sin cargar objetos en memoria. Más eficiente si solo necesitas saber si existe o no.

//        // OPCIÓN C: JPQL
//        No necesitas el mapper ActorMapper — la query construye el DTO directamente
//        Solo trae de BD los campos que necesitas, no la entidad completa
//
//        Inconveniente:
//
//        Más acoplamiento entre el repositorio y el DTO

//        El repositorio es una capa de acceso a datos y no debería saber nada de cómo se presentan esos datos. Cuando pones un new ActorParticipacionDto(...) dentro de la query JPQL, el repositorio está conociendo la estructura del DTO — si cambias el DTO (añades un campo, cambias el constructor) tienes que tocar también el repositorio.
//        Con el mapper en el servicio la separación es limpia:
//
//        Repositorio → devuelve entidades o datos crudos, no sabe nada del DTO
//        Mapper → transforma entidades en DTOs, es su única responsabilidad
//        Servicio → orquesta: llama al repo, usa el mapper, lanza la excepción

        // ESTO DEBERÍA IR EN EL REPO DE MOVIECAST
//        @Query("""
//    SELECT new es.daw.extra_api_peliculas.dto.response.ActorParticipacionDto(
//        m.id,
//        m.title,
//        mc.characterName,
//        mc.screenMinutes
//    )
//    FROM MovieCast mc
//    JOIN mc.movie m
//    WHERE mc.actor.id = :actorId
//""")
//        List<ActorParticipacionDto> findParticipacionesByActorId(@Param("actorId") Long actorId);

        // en el servicio
//        if (actor.getMovieCast() != null && !actor.getMovieCast().isEmpty()) {
//            List<ActorParticipacionDto> participaciones =
//                    movieCastRepository.findParticipacionesByActorId(actorId);
//            throw new ActorConflictException(
//                    "El actor participa en películas y no puede ser eliminado",
//                    participaciones);
//        }



        actorRepository.delete(actor);
    }



}

