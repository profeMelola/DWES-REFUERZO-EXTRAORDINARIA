package es.daw.simulacro_api_peliculas.entity;

import es.daw.simulacro_api_peliculas.enums.Genre;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.util.*;

@Entity
@Table(name = "movies")
@Getter
@Setter
public class Movie {

    /*
Otros GenerationType tienen su contexto pero son casos más específicos:
SEQUENCE — usado en Oracle y PostgreSQL cuando quieres más control sobre el incremento. En MySQL no existe secuencia nativa. No es relevante para vuestro stack.
TABLE — genera PKs usando una tabla auxiliar. Muy poco usado hoy en día, peor rendimiento, prácticamente legacy.
AUTO — deja que Hibernate decida según el dialecto de BD. El problema es que el comportamiento puede variar entre versiones de Hibernate y entre BDs — en producción esa ambigüedad es un riesgo. Por eso en la práctica siempre es mejor ser explícito con IDENTITY.
UUID — este sí merece mención en algún momento, no como GenerationType sino como tipo de PK. Tiene casos de uso reales: APIs públicas donde no quieres exponer IDs secuenciales, sistemas distribuidos, microservicios. Pero para un primer curso de Spring Boot con BD relacional es un concepto avanzado que no aporta valor ahora.
     */

    // Desde Spring Boot 3 + Hibernate 6 es tan sencillo como eso — Hibernate genera el UUID automáticamente.
//    @Id
//    @GeneratedValue(strategy = GenerationType.UUID)
//    private UUID id;
//    Ventajas reales:
//
//    No expones información sobre el volumen de tu negocio (un cliente con id=3 sabe que solo hay 3 clientes)
//    No hay colisiones en sistemas distribuidos — puedes generar IDs en varios nodos sin coordinación
//    Dificulta la enumeración de recursos en la API (/users/1, /users/2...)
//
//    Inconvenientes:
//
//    Peor rendimiento en índices — los UUIDs son aleatorios y fragmentan el índice de la PK
//    Más espacio en disco
//    Las FKs también son UUID — las queries son más verbosas y difíciles de depurar a mano

//    En la práctica empresarial lo más habitual es combinar los dos:
//    PK interna con IDENTITY para las relaciones entre tablas,
//    y un campo code UUID único y público que es lo que expones en la API. Así tienes lo mejor de los dos mundos.

//    @Column(unique = true, nullable = false, updatable = false)
//    private UUID code = UUID.randomUUID(); // este es el que va en los DTOs y URLs

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String title;

    @Column(nullable = false)
    private int releaseYear;

    @Column(nullable = false, length = 30)
    @Enumerated(EnumType.STRING)
    private Genre genre;

    @Column(nullable = false)
    private boolean active = true;

    // O puedes asignarlo en el servicio antes de persistir,
    // que es lo que hacéis vosotros con review.setCreatedAt(LocalDate.now()).
    // Ambas opciones son válidas — @PrePersist garantiza que nunca se olvide, el servicio da más control.
//    @PrePersist
//    void onCreate() {
//        this.createdAt = LocalDate.now();
//    }

    @OneToMany(mappedBy = "movie",
                cascade = CascadeType.ALL,
                orphanRemoval = true)
    private Set<MovieCast> movieCast = new HashSet<>();

    @OneToMany(mappedBy = "movie", fetch = FetchType.LAZY)
    private List<Release> releases = new ArrayList<>();


    // ESTRATEGIAS
    // Si se borra una película ¿qué pasa con sus reseñas?
    // Dos Opciones posibles:
//    opción 1 ->Con cascade = CascadeType.ALL + orphanRemoval = true en Movie → si borras una película se borran sus reseñas.
//    Semánticamente tiene sentido: una reseña sin película no tiene razón de existir.
//    opción 2 -> Sin cascade como lo tienes ahora → si intentas borrar una película que tiene reseñas,
//    la BD lanzará un error de FK. Tendrías que borrar las reseñas manualmente antes.
/*
SI SE BORRA EL PADRE SE BORRAN LOS HIJOS
cascade = CascadeType.ALL
Propagas todas las operaciones de Movie a sus Reviews: persist, merge, remove, refresh, detach.
Si borras una película con movieRepository.delete(movie),
Hibernate borra también todas sus reseñas en cascada.

SI UN HIJO SE DESVINCULA DEL PADRE, SE BORRA
orphanRemoval = true
Si quitas una reseña de la colección movie.getReviews() sin borrar la película,
Hibernate borra esa reseña de BD automáticamente porque ha quedado "huérfana" — sin padre.
 */
    @OneToMany(mappedBy = "movie",fetch = FetchType.LAZY)
    private List<Review> reviews = new ArrayList<>();


    // El gestor es el que tiene cascade, orphanRemoval y helpers.
    // El lado inverso solo tiene mappedBy y punto.
    // Si haces movie.removeMovieDirector(movieDirector),
    // ese MovieDirector queda huérfano — sin película — y Hibernate lo borra de BD automáticamente.
    @OneToMany(mappedBy = "Movie",fetch = FetchType.LAZY,cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<MovieDirector> movieDirector = new HashSet<>();
    // LAZY significa que Hibernate no carga la colección cuando carga la entidad.
    // Solo pone un proxy en su lugar.
    // La colección real se carga de BD cuando alguien la accede por primera vez —
    // en nuestro caso cuando hacemos movie.getMovieDirectors().
    // Para que esa carga ocurra, Hibernate necesita una sesión abierta — es decir, una conexión activa a BD.
    // La sesión de Hibernate se abre al entrar en un método @Transactional y se cierra al salir.
    // @Transactional(readOnly = true)  // sesión abierta durante todo el método
    // Si accedieras a movie.getMovieDirectors() fuera de la transacción — por ejemplo en el controlador o en la vista
    // org.hibernate.LazyInitializationException:
    //failed to lazily initialize a collection:
    //could not initialize proxy - no Session


    // ---------- métodos helper!!! ------------
    public void addMovieCast(MovieCast movieCast){
        this.movieCast.add(movieCast);
        movieCast.setMovie(this);
    }

    public void removeMovieCast(MovieCast movieCast){
        this.movieCast.remove(movieCast);
        movieCast.setMovie(null);
    }

    public void addReview(Review review){
        this.reviews.add(review);
        review.setMovie(this);
    }

    public void removeReview(Review review){
        this.reviews.remove(review);
        review.setMovie(null);
    }

    public void addMovieDirector(MovieDirector movieDirector){
        this.movieDirector.add(movieDirector);
        movieDirector.setMovie(this);
    }

    public void removeMovieDirector(MovieDirector movieDirector){
        this.movieDirector.remove(movieDirector);
        movieDirector.setMovie(null);
    }


}
