package es.daw.simulacro_api_peliculas.mapper;


import es.daw.simulacro_api_peliculas.dto.response.MovieDirectorResponseDto;
import es.daw.simulacro_api_peliculas.entity.MovieDirector;
import org.springframework.stereotype.Component;

public class MovieDirectorMapper {

    public MovieDirectorResponseDto toResponseDto(MovieDirector md) {
        return new MovieDirectorResponseDto(
                md.getDirector().getId(),
                md.getDirector().getFullName(),
                md.getDirector().getNationality(),
                md.getRole(),
                md.isCredited()
        );
    }
}
