package es.daw.simulacro_api_peliculas.dto.error;

import es.daw.simulacro_api_peliculas.dto.response.ActorCastDto;

import java.time.LocalDateTime;
import java.util.List;

public record ActorConflictResponseDto(
        LocalDateTime timestamp,
        int status,
        String error,      // Texto HTTP estándar: "Not Found", "Conflict", etc.
        String message,    // Mensaje de negocio legible
        String path,        // URI que originó el error
        List<ActorParticipacionDto> participaciones
) {
}
