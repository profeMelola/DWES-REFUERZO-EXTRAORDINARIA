package es.daw.simulacro_api_peliculas.service;

import es.daw.simulacro_api_peliculas.dto.review.ReviewRequestDto;
import es.daw.simulacro_api_peliculas.dto.review.ReviewResponseDto;
import es.daw.simulacro_api_peliculas.entity.Movie;
import es.daw.simulacro_api_peliculas.entity.Review;
import es.daw.simulacro_api_peliculas.exception.ResourceNotFoundException;
import es.daw.simulacro_api_peliculas.mapper.ReviewMapper;
import es.daw.simulacro_api_peliculas.repository.MovieRepository;
import es.daw.simulacro_api_peliculas.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final MovieRepository movieRepository;
    private final ReviewMapper reviewMapper;

    @Transactional
    public ReviewResponseDto addReview(Long movieId, ReviewRequestDto dto) {

        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new ResourceNotFoundException("Película no encontrada con id: "+movieId));

        Review review = Review.builder()
        .movie(movie)
        .author(dto.author())
                .body(dto.body())
                .rating(dto.rating())
                .createdAt(LocalDate.now())
                .active(true)
                .build();

        // salvar en BD
        Review saved = reviewRepository.save(review);

        // no  hacemos la conversión de Entity a DTO directamente en el servicio!!!!!
        return reviewMapper.toResponseDto(saved);


    }
}
