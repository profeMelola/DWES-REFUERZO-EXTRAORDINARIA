package es.daw.simulacro_api_peliculas.dto.review;

import java.time.LocalDate;

public record ReviewResponseDto(
        Long id,
        String author,
        String body,
        int rating,
        LocalDate createdAt,
        Long movieId,
        String movieTitle
){}
