package es.daw.simulacro_api_peliculas.service;

import es.daw.simulacro_api_peliculas.dto.request.MovieDirectorRequestDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieDirectorResponseDto;
import es.daw.simulacro_api_peliculas.entity.Director;
import es.daw.simulacro_api_peliculas.entity.Movie;
import es.daw.simulacro_api_peliculas.entity.MovieDirector;
import es.daw.simulacro_api_peliculas.entity.MovieDirectorId;
import es.daw.simulacro_api_peliculas.exception.BusinessRuleException;
import es.daw.simulacro_api_peliculas.exception.ConflictException;
import es.daw.simulacro_api_peliculas.exception.ResourceNotFoundException;
import es.daw.simulacro_api_peliculas.mapper.MovieDirectorMapper;
import es.daw.simulacro_api_peliculas.repository.DirectorRepository;
import es.daw.simulacro_api_peliculas.repository.MovieRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class MovieDirectorService {

    private final MovieRepository movieRepository;
    private final DirectorRepository directorRepository;
    private final MovieDirectorMapper movieDirectorMapper;


    public void addDirectorToMovie(Long movieId, MovieDirectorRequestDto dto) {

        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Película no encontrada con id: " + movieId));

        Director director = directorRepository.findById(dto.directorId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Director no encontrado con id: " + dto.directorId()));

        if (!director.isActive()) {
            throw new BusinessRuleException(
                    "El director con id " + dto.directorId() + " no está activo y no puede asignarse a una película");
        }

        // PENDIENTE!!! Una película no puede tener más de un DIRECTOR (pero sí varios CO_DIRECTOR o ASSISTANT))

        MovieDirectorId id = new MovieDirectorId(movieId, dto.directorId());
        boolean alreadyExists = movie.getMovieDirector().stream()
                .anyMatch(md -> md.getId().equals(movieId));

        if (alreadyExists) {
            throw new ConflictException(
                    "El director ya está asignado a esta película");
        }

        MovieDirector movieDirector = new MovieDirector();
        movieDirector.setId(id);
        movieDirector.setDirector(director);
        movieDirector.setRole(dto.role());
        movieDirector.setCredited(dto.credited());

        movie.addMovieDirector(movieDirector);
    }

    @Transactional(readOnly = true)
    public List<MovieDirectorResponseDto> getDirectorsByMovie(Long movieId) {

        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Película no encontrada con id: " + movieId));

        return movie.getMovieDirector().stream()
                .map(movieDirectorMapper::toResponseDto)
                .toList();
    }
}
