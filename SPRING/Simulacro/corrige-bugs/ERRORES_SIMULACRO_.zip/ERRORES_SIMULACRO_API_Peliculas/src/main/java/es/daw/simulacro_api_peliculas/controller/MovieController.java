package es.daw.simulacro_api_peliculas.controller;

import es.daw.simulacro_api_peliculas.dto.request.MovieCastRequestDto;
import es.daw.simulacro_api_peliculas.dto.response.ActorCastDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieCastResponseDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieResponseDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieWithCastDto;
import es.daw.simulacro_api_peliculas.enums.Genre;
import es.daw.simulacro_api_peliculas.service.MovieCastService;
import es.daw.simulacro_api_peliculas.service.MovieService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/movies")
@RequiredArgsConstructor
public class MovieController {

    private final MovieCastService movieCastService;
    private final MovieService movieService;

    /**
     *
     * POST /movies/{id}/cast
     * Añade un actor a la película indicada.
     * Devuelve 201 Created si la operación se realiza correctamente.
     */
    @PostMapping("/{id}/cast-con-ResponseStatus")
    @ResponseStatus(HttpStatus.CREATED)
    public void addActorToMovie2(
            @PathVariable Long id,
            @Valid @RequestBody MovieCastRequestDto dto) {

        movieCastService.addActorToMovie(id, dto);
    }

    @PostMapping("/{id}/cast")
    public ResponseEntity<Void> addActorToMovie(
            @PathVariable Long id,
            @Valid @RequestBody MovieCastRequestDto dto) {

            movieCastService.addActorToMovie(id, dto);
            return ResponseEntity.status(HttpStatus.CREATED).body(null);
    }

    @GetMapping("/{movieId}/cast/{actorId}")
    public ResponseEntity<MovieCastResponseDto> getMovieCast(
            @PathVariable Long movieId,
            @PathVariable Long actorId) {

        MovieCastResponseDto dto = movieCastService.getMovieCast(movieId, actorId);
        return ResponseEntity.ok(dto);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMovie(@PathVariable Long id) {
        movieCastService.deleteMovie(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/with-cast")
    public ResponseEntity<List<MovieWithCastDto>> getMovieCastWithCast(){
        return ResponseEntity.ok(movieService.getAllMoviesWithCast());

    }

    @GetMapping("/{id}")
    public ResponseEntity<MovieResponseDto> getMovie(@PathVariable Long id) {
        MovieResponseDto dto = movieService.getMovie(id);
        return ResponseEntity.ok(dto);
    }

    @GetMapping("/{id}/cast")
    public ResponseEntity<List<ActorCastDto>> getMovieCast(@PathVariable Long id) {
        List<ActorCastDto> cast = movieService.getMovieCast(id);
        return ResponseEntity.ok(cast);
    }

    // ----------------- LISTADO DE PELÍCULAS --------------
    // SIN PAGINACIÓN
//    @GetMapping
//    public ResponseEntity<List<MovieResponseDto>> getMovies(
//            @RequestParam(required = false)Genre genre ){
//        return ResponseEntity.ok(movieService.getMovies(genre));
//    }

    // CON PAGINACIÓN
    // MEJORA!!! PENDIENTE!!! Los parámetros por defecto de la paginación que se leean de un properties
    @GetMapping
    public ResponseEntity<Page<MovieResponseDto>> getMovies(
            @RequestParam(required = false)Genre genre ,
            @PageableDefault(size= 5, sort="title", direction = Sort.Direction.ASC) Pageable pageable){

        // Pageable.of(); nooooooooooooooooooooooo
        return ResponseEntity.ok(movieService.getMovies(genre, pageable));
    }


}
