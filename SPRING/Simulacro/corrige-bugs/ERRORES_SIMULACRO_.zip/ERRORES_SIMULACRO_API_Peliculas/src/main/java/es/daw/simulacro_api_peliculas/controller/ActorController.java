package es.daw.simulacro_api_peliculas.controller;

import es.daw.simulacro_api_peliculas.service.MovieCastService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/actors")
@RequiredArgsConstructor
public class ActorController {

    private final MovieCastService movieCastService;

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteActor(@PathVariable Long id) {
        movieCastService.deleteActor(id);
        return ResponseEntity.noContent().build();
    }

    // PENDIENTE!!!
    // PARA PROBAR ENUMERADO DE NACIONALIDADES DEL ACTOR
    // PENDIENTE: endpoints: post y put / patch (modificar la nacionalidad el actor)
}
