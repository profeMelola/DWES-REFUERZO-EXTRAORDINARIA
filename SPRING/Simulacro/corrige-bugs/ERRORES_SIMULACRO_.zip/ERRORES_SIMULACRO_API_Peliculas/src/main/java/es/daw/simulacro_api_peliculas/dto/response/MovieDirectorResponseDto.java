package es.daw.simulacro_api_peliculas.dto.response;


import es.daw.simulacro_api_peliculas.enums.DirectorRole;

public record MovieDirectorResponseDto(
        Long directorId,
        String fullName,
        String nationality,
        DirectorRole role,
        boolean credited
) {}
