package es.daw.simulacro_api_peliculas.controller;

import es.daw.simulacro_api_peliculas.dto.review.ReviewRequestDto;
import es.daw.simulacro_api_peliculas.dto.review.ReviewResponseDto;
import es.daw.simulacro_api_peliculas.service.ReviewService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/movies/{id}/reviews")
@RequiredArgsConstructor
public class ReviewController {

    private final ReviewService reviewService;

    @PostMapping
    public ResponseEntity<ReviewResponseDto> addReview(
            @PathVariable Long id,
            @Valid @RequestBody ReviewRequestDto dto) {

        ReviewResponseDto response = reviewService.addReview(id, dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }
}
