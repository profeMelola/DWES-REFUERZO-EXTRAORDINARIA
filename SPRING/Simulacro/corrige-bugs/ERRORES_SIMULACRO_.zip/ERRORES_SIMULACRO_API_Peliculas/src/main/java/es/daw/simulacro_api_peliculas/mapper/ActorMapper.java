package es.daw.simulacro_api_peliculas.mapper;

import es.daw.simulacro_api_peliculas.dto.error.ActorParticipacionDto;
import es.daw.simulacro_api_peliculas.entity.Actor;
import es.daw.simulacro_api_peliculas.entity.MovieCast;
import org.springframework.stereotype.Component;

@Component
public class ActorMapper {

    public ActorParticipacionDto toParticipacionDto(MovieCast mc){
        return new ActorParticipacionDto(
                mc.getMovie().getId(),
                mc.getMovie().getTitle(),
                mc.getCharacterName(),
                mc.getScreenMinutes()
        );

    }
}
