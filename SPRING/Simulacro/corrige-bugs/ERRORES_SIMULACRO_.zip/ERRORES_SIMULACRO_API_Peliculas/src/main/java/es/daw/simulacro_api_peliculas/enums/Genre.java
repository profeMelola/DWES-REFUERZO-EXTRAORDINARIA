package es.daw.simulacro_api_peliculas.enums;

public enum Genre {
    ACTION,
    SCI_FI,
    DRAMA,
    WAR,
    THRILLER,
    HORROR
}
