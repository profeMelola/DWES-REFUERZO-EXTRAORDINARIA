package es.daw.simulacro_api_peliculas.controller;

import es.daw.simulacro_api_peliculas.dto.request.MovieDirectorRequestDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieDirectorResponseDto;
import es.daw.simulacro_api_peliculas.service.MovieDirectorService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/movies")
@RequiredArgsConstructor
public class MovieDirectorController {

    private final MovieDirectorService movieDirectorService;

    @PostMapping("/{id}/directors")
    public ResponseEntity<Void> addDirectorToMovie(
            @PathVariable Long id,
            @Valid @RequestBody MovieDirectorRequestDto dto) {

        movieDirectorService.addDirectorToMovie(id, dto);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @GetMapping("/{id}/directors")
    public ResponseEntity<List<MovieDirectorResponseDto>> getDirectorsByMovie(
            @PathVariable Long id) {

        List<MovieDirectorResponseDto> directors = movieDirectorService.getDirectorsByMovie(id);
        return ResponseEntity.ok(directors);
    }
}
