package es.daw.simulacro_api_peliculas.repository;

import es.daw.simulacro_api_peliculas.entity.Director;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DirectorRepository extends JpaRepository<Director, Long> {}
