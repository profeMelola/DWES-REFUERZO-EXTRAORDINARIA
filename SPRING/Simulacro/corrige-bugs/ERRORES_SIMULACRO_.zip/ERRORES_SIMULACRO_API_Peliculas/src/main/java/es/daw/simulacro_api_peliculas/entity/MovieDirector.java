package es.daw.simulacro_api_peliculas.entity;


import es.daw.simulacro_api_peliculas.enums.DirectorRole;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "movie_director")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MovieDirector {

    @Id
    private MovieDirectorId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="movie_id")
    private Movie movie;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name="director_id")
    private Director director;

    @Column(nullable = false, length = 30)
    private DirectorRole role;

    @Column(nullable = false)
    private boolean credited = true;
}
