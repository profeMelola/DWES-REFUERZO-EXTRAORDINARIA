package es.daw.simulacro_api_peliculas.entity;

import es.daw.simulacro_api_peliculas.enums.Genre;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name="directors")
@Getter
@Setter
public class Director {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    String fullName;

    @Column(nullable = false, length = 60)
    String nationality;

    @Column(nullable = false)
    boolean active = true;

    @OneToMany(mappedBy = "director")
    private Set<MovieDirector> movieDirectors = new HashSet<MovieDirector>();

    // Pendiente verificar si es mejor usar @Prepersist ?????


}
