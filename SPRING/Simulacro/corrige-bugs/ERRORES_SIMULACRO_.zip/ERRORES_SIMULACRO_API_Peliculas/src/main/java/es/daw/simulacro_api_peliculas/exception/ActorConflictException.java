package es.daw.simulacro_api_peliculas.exception;

import es.daw.simulacro_api_peliculas.dto.error.ActorParticipacionDto;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.List;

@ResponseStatus(HttpStatus.CONFLICT)
@Getter
public class ActorConflictException extends RuntimeException{

    private final List<ActorParticipacionDto> participaciones;

    public ActorConflictException(String message, List<ActorParticipacionDto> participaciones) {
        super(message);
        this.participaciones = participaciones;
    }


}
