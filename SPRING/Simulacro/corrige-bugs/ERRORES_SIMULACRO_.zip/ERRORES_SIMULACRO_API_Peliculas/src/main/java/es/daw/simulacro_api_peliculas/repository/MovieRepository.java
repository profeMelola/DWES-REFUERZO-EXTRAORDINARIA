package es.daw.simulacro_api_peliculas.repository;

import es.daw.simulacro_api_peliculas.dto.report.TopGrossingMovieReport;
import es.daw.simulacro_api_peliculas.entity.Movie;
import es.daw.simulacro_api_peliculas.enums.Genre;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface MovieRepository extends JpaRepository<Movie, Long> {
    @Query("""
    SELECT DISTINCT m FROM Movie m 
    JOIN FETCH m.movieCast mc
    JOIN FETCH mc.actor
        """)
    List<Movie> findAllWithCast();


    @Query("""
        SELECT new es.daw.simulacro_api_peliculas.dto.report.TopGrossingMovieReport
        (
            m.id,
            m.title,
            m.genre,
            count(boe.id),
            sum(boe.screens),
            sum(boe.gross)
        )
        FROM Movie m
            LEFT JOIN m.releases r
            LEFT JOIN r.boxOfficeEntries boe
        WHERE m.active = true
          AND (r.id IS NULL OR r.active = true)
          AND (boe.id IS NULL OR boe.active = true)
          AND (:genre IS NULL OR m.genre = :genre)
          AND (:from  IS NULL OR boe.periodStart >= :from)
          AND (:to    IS NULL OR boe.periodEnd   <= :to)    
        GROUP BY m.id, m.title, m.genre
        ORDER BY SUM(boe.gross) DESC
        
    """)
    List<TopGrossingMovieReport> topGrossingMovies(
            //@Param("genre") String genre,
            @Param("genre") Genre genre,
            @Param("from") LocalDate from,
            @Param("to")    LocalDate to,
            Pageable pageable
    );



    @Query(value = """
SELECT new es.daw.simulacro_api_peliculas.dto.report.TopGrossingMovieReport(
    m.id,
    m.title,
    m.genre,
    COUNT(boe.id),
    SUM(boe.screens),
    SUM(boe.gross)
)
FROM Movie m
    LEFT JOIN m.releases r
    LEFT JOIN r.boxOfficeEntries boe
WHERE m.active = true
  AND (r.id IS NULL OR r.active = true)
  AND (boe.id IS NULL OR boe.active = true)
  AND (:genre IS NULL OR CAST(m.genre AS string) = :genre)
  AND (:from  IS NULL OR boe.periodStart >= :from)
  AND (:to    IS NULL OR boe.periodEnd   <= :to)
GROUP BY m.id, m.title, m.genre
ORDER BY SUM(boe.gross) DESC
""",
            countQuery = """
SELECT COUNT(DISTINCT m.id)
FROM Movie m
    LEFT JOIN m.releases r
    LEFT JOIN r.boxOfficeEntries boe
WHERE m.active = true
  AND (r.id IS NULL OR r.active = true)
  AND (boe.id IS NULL OR boe.active = true)
  AND (:genre IS NULL OR CAST(m.genre AS string) = :genre)
  AND (:from  IS NULL OR boe.periodStart >= :from)
  AND (:to    IS NULL OR boe.periodEnd   <= :to)
""")
    Page<TopGrossingMovieReport> topGrossingMoviesPage(
            @Param("genre") String genre,
            @Param("from") LocalDate from,
            @Param("to") LocalDate to,
            Pageable pageable
    );


    //List<Movie> findByGenre(Genre genre);

    Page<Movie> findByGenre(Genre genre, Pageable pageable);


    // Si no uso Page, pierdo metadatos de paginación...
    //List<Movie> findByGenre2(Genre genre,Pageable pageable);

    Page<Movie> findByGenreIgnoreCase(Genre genre, Pageable pageable);
}


