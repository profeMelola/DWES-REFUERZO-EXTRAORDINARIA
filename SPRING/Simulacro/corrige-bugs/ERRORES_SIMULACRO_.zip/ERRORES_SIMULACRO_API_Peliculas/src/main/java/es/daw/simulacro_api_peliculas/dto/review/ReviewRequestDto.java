package es.daw.simulacro_api_peliculas.dto.review;

import jakarta.validation.constraints.*;

public record ReviewRequestDto(
        @NotBlank(message = "El autor es obligatorio")
        @Size(max = 80, message = "El autor no puede superar 80 caracteres")
        String author,

        @NotBlank(message = "El cuerpo de la reseña es obligatorio")
        @Size(max = 500, message = "La reseña no puede superar 500 caracteres")
        String body,

        @NotNull(message = "La valoración es obligatoria")
        @Min(value = 1, message = "La valoración mínima es 1")
        @Max(value = 10, message = "La valoración máxima es 10")
        Integer rating
){}

