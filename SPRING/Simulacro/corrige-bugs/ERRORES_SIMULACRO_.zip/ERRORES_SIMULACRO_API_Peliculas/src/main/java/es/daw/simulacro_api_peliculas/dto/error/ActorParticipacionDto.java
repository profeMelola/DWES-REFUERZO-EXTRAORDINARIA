package es.daw.simulacro_api_peliculas.dto.error;

public record ActorParticipacionDto(
        Long movieId,
        String movieTitle,
        String characterName,
        short screenMinutes
) {
}
