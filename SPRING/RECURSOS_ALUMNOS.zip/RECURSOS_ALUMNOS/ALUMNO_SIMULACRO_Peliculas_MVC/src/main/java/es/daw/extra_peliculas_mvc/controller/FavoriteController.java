package es.daw.extra_peliculas_mvc.controller;

import es.daw.extra_peliculas_mvc.entity.AppUser;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/favorites")
public class FavoriteController {


    @GetMapping
    public String list(@AuthenticationPrincipal AppUser user, Model model) {

        // TODO ...

        return "";

    }

    @PostMapping("/add/{movieId}")
    public String add(@AuthenticationPrincipal AppUser user,
                      @PathVariable Long movieId,
                      RedirectAttributes redirectAttributes) {

        // TODO ...

        return "";
    }

    @PostMapping("/{id}/delete")
    public String delete(@AuthenticationPrincipal AppUser user,
                         @PathVariable Long id,
                         RedirectAttributes redirectAttributes) {
        // TODO ...

        return "";
    }
}
