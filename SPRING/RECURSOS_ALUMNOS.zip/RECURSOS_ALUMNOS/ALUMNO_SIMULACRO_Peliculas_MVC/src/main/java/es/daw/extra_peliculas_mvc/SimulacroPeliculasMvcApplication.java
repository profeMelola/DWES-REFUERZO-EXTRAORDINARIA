package es.daw.extra_peliculas_mvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimulacroPeliculasMvcApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimulacroPeliculasMvcApplication.class, args);
    }

}
