package es.daw.extra_peliculas_mvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimulacroPeliculasMvcApplicationTests {

    @Test
    void contextLoads() {
    }

}
