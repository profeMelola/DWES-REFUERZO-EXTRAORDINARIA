package es.daw.simulacro_api_peliculas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimulacroApiPeliculasApplicationTests {

    @Test
    void contextLoads() {
    }

}
