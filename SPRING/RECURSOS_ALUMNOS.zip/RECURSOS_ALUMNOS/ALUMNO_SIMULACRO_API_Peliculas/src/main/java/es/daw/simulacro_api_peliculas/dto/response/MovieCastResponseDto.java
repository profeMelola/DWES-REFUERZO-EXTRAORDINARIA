package es.daw.simulacro_api_peliculas.dto.response;

import es.daw.simulacro_api_peliculas.enums.Genre;


public record MovieCastResponseDto(
        Long movieId,
        String title,
        int releaseYear,
        Genre genre,
        boolean active,

        Long actorId,// ide el actor recién añadido (lo uso para montar el Location)
        String actorName


) {}