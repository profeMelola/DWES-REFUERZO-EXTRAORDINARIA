package es.daw.simulacro_api_peliculas.entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "countries")
public class Country {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 3)
    private String code;

    @Column(nullable = false, length = 80)
    private String name;

    @Column(nullable = false)
    private boolean active = true;

    @OneToMany(mappedBy = "country")
    private List<Distributor> distributors = new ArrayList<>();

    @OneToMany(mappedBy = "country")
    private List<BoxOfficeEntry> boxOfficeEntries = new ArrayList<>();


}
