package es.daw.simulacro_api_peliculas.dto.response;

import es.daw.simulacro_api_peliculas.enums.Genre;

/** Respuesta para Movie */
public record MovieResponseDto(
        Long id,
        String title,
        int releaseYear,
        //String genre,
        Genre genre,
        boolean active
) {}