package es.daw.simulacro_api_peliculas.entity;

import es.daw.simulacro_api_peliculas.enums.Genre;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "movies")
@Getter
@Setter
public class Movie {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String title;

    @Column(nullable = false)
    private int releaseYear;

    @Column(nullable = false, length = 30)
    @Enumerated(EnumType.STRING)
    private Genre genre;

    @Column(nullable = false)
    private boolean active = true;

    @OneToMany(mappedBy = "movie",
                cascade = CascadeType.ALL,
                orphanRemoval = true)
    private Set<es.daw.simulacro_api_peliculas.entity.MovieCast> movieCast = new HashSet<>();

    @OneToMany(mappedBy = "movie", fetch = FetchType.LAZY)
    private List<es.daw.simulacro_api_peliculas.entity.Release> releases = new ArrayList<>();

    public void addMovieCast(es.daw.simulacro_api_peliculas.entity.MovieCast movieCast){
        this.movieCast.add(movieCast);
        movieCast.setMovie(this);
    }

    public void removeMovieCast(es.daw.simulacro_api_peliculas.entity.MovieCast movieCast){
        this.movieCast.remove(movieCast);
        movieCast.setMovie(null);
    }



}
