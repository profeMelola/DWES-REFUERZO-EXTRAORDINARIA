package es.daw.simulacro_api_peliculas.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;


@Entity
@Table(name = "movie_cast")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MovieCast {

    @EmbeddedId
    private MovieCastId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("movieId")
    @JoinColumn(name = "movie_id")
    private Movie movie;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("actorId")
    @JoinColumn(name = "actor_id")
    private Actor actor;

    @Column(nullable = false, length = 80)
    private String characterName;

    @Column(nullable = false)
    private short screenMinutes;

    @Column(precision = 12, scale = 2)
    private BigDecimal salaryOverride;

    private boolean active;

    @Override
    public String toString() {
        return "MovieCast{" +
               "movie=" + movie.getTitle() +
               ", actor=" + actor.getFullName() +
               ", personaje=" + characterName +
               '}';
    }
}
