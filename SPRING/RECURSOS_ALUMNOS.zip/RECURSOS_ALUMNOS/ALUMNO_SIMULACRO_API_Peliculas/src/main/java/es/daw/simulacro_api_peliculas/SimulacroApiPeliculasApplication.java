package es.daw.simulacro_api_peliculas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimulacroApiPeliculasApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimulacroApiPeliculasApplication.class, args);
    }

}
