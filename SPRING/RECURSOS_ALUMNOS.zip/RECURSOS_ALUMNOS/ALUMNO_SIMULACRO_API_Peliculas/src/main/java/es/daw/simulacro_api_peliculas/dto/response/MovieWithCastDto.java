package es.daw.simulacro_api_peliculas.dto.response;

import es.daw.simulacro_api_peliculas.enums.Genre;

import java.util.List;

// Película con su lista de actores
public record MovieWithCastDto(
        Long id,
        String title,
        int releaseYear,
        Genre genre,
        boolean active,
        List<ActorCastDto> cast
) {}
