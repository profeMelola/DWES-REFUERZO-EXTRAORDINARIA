package es.daw.simulacro_api_peliculas.mapper;

import es.daw.simulacro_api_peliculas.dto.response.ActorCastDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieResponseDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieWithCastDto;
import es.daw.simulacro_api_peliculas.entity.Movie;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class MovieMapper {


    public MovieWithCastDto toMovieWithCastDto(Movie movie){
        List<ActorCastDto> actorCastDtos = movie.getMovieCast().stream()
                .map(mc -> new ActorCastDto(
                        mc.getActor().getId(),
                        mc.getActor().getStageName(),
                        mc.getCharacterName(),
                        mc.getScreenMinutes()
                ))
                .toList();
        return new MovieWithCastDto(
                movie.getId(),
                movie.getTitle(),
                movie.getReleaseYear(),
                movie.getGenre(),
                movie.isActive(),
                actorCastDtos
        );

    }

    public MovieResponseDto toResponseDto(Movie movie) {
        return new MovieResponseDto(
                movie.getId(),
                movie.getTitle(),
                movie.getReleaseYear(),
                movie.getGenre(),
                movie.isActive()
        );
    }

    public List<ActorCastDto> toActorCastDtos(Movie movie) {
        return movie.getMovieCast().stream()
                .map(mc -> new ActorCastDto(
                        mc.getActor().getId(),
                        mc.getActor().getStageName(),
                        mc.getCharacterName(),
                        mc.getScreenMinutes()
                ))
                .toList();
    }

}
