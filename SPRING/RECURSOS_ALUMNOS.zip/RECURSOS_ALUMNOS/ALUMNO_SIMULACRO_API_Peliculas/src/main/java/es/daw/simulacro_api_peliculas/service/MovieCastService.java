package es.daw.simulacro_api_peliculas.service;

import es.daw.simulacro_api_peliculas.dto.request.MovieCastRequestDto;
import es.daw.simulacro_api_peliculas.dto.response.MovieCastResponseDto;
import es.daw.simulacro_api_peliculas.entity.Actor;
import es.daw.simulacro_api_peliculas.entity.Movie;
import es.daw.simulacro_api_peliculas.entity.MovieCast;
import es.daw.simulacro_api_peliculas.entity.MovieCastId;
import es.daw.simulacro_api_peliculas.exception.ConflictException;
import es.daw.simulacro_api_peliculas.exception.ResourceNotFoundException;
import es.daw.simulacro_api_peliculas.repository.ActorRepository;
import es.daw.simulacro_api_peliculas.repository.MovieCastRepository;
import es.daw.simulacro_api_peliculas.repository.MovieRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class MovieCastService {

    private final MovieRepository movieRepository;
    private final ActorRepository actorRepository;
    private final MovieCastRepository movieCastRepository;


    @Transactional
    public void addActorToMovie(Long movieId, MovieCastRequestDto dto) {

        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Película no encontrado con id: "+movieId
                ));

        Actor actor = actorRepository.findById(dto.actorId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Actor no encontrado con id: " + dto.actorId()
                ));

        MovieCastId castId = new MovieCastId(movieId, dto.actorId());
        boolean alreadyExists = movie.getMovieCast().stream()
                .anyMatch(mc -> mc.getId().equals(castId));

        if(alreadyExists){
            throw new ConflictException(
                    "El actor ya tiene un rol en esta película"
            );
        }

        MovieCast movieCast = new MovieCast();
        movieCast.setId(castId);
        movieCast.setMovie(movie);
        movieCast.setActor(actor);
        movieCast.setCharacterName(dto.characterName());
        movieCast.setScreenMinutes(dto.screenMinutes());
        movieCast.setSalaryOverride(dto.salaryOverride());

        movieRepository.save(movie);

        System.out.println("****************************");
        System.out.println("** LISTADO DE PERSONAJES: " + movie.getMovieCast());
        System.out.println("****************************");

    }

    @Transactional(readOnly = true)
    public MovieCastResponseDto getMovieCast(Long movieId, Long actorId) {

        MovieCastId id = new MovieCastId(movieId, actorId);

        MovieCast movieCast = movieCastRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "MovieCast no encontrado para movieId: " + movieId + " actorId: " + actorId));

        Movie movie = movieCast.getMovie();
        Actor actor = movieCast.getActor();

        return new MovieCastResponseDto(
                movie.getId(),
                movie.getTitle(),
                movie.getReleaseYear(),
                movie.getGenre(),
                movie.isActive(),
                actor.getId(),
                actor.getStageName()
        );
    }

    @Transactional
    public void deleteMovie(Long movieId) {
        Movie movie = movieRepository.findById(movieId)
                .orElseThrow(() -> new ResourceNotFoundException("Película no encontrada con id: " + movieId));
        movieRepository.delete(movie);
    }


    @Transactional
    public void deleteActor(Long actorId) {

        Actor actor = actorRepository.findById(actorId)
                .orElseThrow(() -> new ResourceNotFoundException("Actor no encontrado con id: " + actorId));

        boolean hashCast = actor.getMovieCast() != null && !actor.getMovieCast().isEmpty();
        if (hashCast) {
            throw new ConflictException("El actor con id "+actorId+" participa en películas y no se puede borrar");
        }

        actorRepository.delete(actor);
    }



}

