package es.daw.simulacro_api_peliculas.entity;

import jakarta.persistence.*;
import lombok.Getter;

import java.util.Set;

@Entity
@Table(name = "actors")
@Getter
public class Actor {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 80)
    private String stageName;

    @Column(nullable = false, length = 120)
    private String fullName;

    @Column(length = 60)
    private String nationality;

    @Column(nullable = false)
    private boolean active = true;

    @OneToMany(mappedBy = "actor")
    private Set<es.daw.simulacro_api_peliculas.entity.MovieCast>  movieCast;

    public void addMovieCast(es.daw.simulacro_api_peliculas.entity.MovieCast movieCast){
        this.movieCast.add(movieCast);
        movieCast.setActor(this);
    }

    public void removeMovieCast(es.daw.simulacro_api_peliculas.entity.MovieCast movieCast){
        this.movieCast.remove(movieCast);
        movieCast.setActor(null);
    }

}