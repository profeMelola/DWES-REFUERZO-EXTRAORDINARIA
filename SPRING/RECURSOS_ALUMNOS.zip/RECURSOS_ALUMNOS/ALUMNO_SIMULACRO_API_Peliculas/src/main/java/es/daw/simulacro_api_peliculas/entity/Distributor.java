package es.daw.simulacro_api_peliculas.entity;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "distributors")
public class Distributor {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 120)
    private String name;

    @Column(nullable = false)
    private boolean active = true;


    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name="country_id", nullable = false)
    Country country;

    @OneToMany(mappedBy = "distributor", fetch = FetchType.LAZY)
    private List<Release> releases = new ArrayList<>();

}