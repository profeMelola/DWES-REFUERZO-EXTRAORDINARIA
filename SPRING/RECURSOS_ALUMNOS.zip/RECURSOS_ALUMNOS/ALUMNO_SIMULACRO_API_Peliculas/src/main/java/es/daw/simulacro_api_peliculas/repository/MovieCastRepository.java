package es.daw.simulacro_api_peliculas.repository;

import es.daw.simulacro_api_peliculas.entity.MovieCast;
import es.daw.simulacro_api_peliculas.entity.MovieCastId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovieCastRepository extends JpaRepository<MovieCast, MovieCastId> {}